<script lang="ts" setup>

</script>

<template>
  <div class="h-[700px] bg-gray-100 rounded-md overflow-hidden"></div>
</template>

<style lang="scss" scoped>

</style>