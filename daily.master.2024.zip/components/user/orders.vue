<script lang="ts" setup>

</script>

<template>
  <div class="bg-white p-6 rounded-md flex flex-col gap-6"> 
    <div class="bg-gray-100 p-3 rounded-md">
      ㅇㅇㅇ
    </div>
    <div class="grid grid-cols-2 gap-4">
      <CardOrder />
    </div>
    
  </div>
</template>

<style lang="scss" scoped>

</style>