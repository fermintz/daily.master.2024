<script lang="ts" setup>

</script>

<template>
  <div class="h-px bg-gray-300 my-3"></div>
</template>

<style lang="scss" scoped>

</style>