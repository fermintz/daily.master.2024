<script lang="ts" setup>

</script>

<template>
  <div>
    <div class="flex items-center justify-between mb-6">
      <h2 class="text-2xl font-bold">매장등록</h2>
    </div>

    <div>
      <ShopInfo />
    </div>
  </div>
</template>

<style lang="scss" scoped>

</style>