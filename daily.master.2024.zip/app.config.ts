export default defineAppConfig({
  ui: {
    primary: 'blue',
    modal:{
      width:' sm:max-w-none w-auto',
    },

  }
})